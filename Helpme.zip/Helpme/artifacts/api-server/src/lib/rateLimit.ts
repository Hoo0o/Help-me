const _map = new Map<string, { count: number; resetAt: number }>();

// تنظيف المفاتيح المنتهية كل دقيقة — يمنع memory leak
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of _map) {
    if (now > val.resetAt) _map.delete(key);
  }
}, 60_000);

export function isRateLimited(ip: string, limit = 20, windowMs = 60_000): boolean {
  const now = Date.now();
  const entry = _map.get(ip);
  if (!entry || now > entry.resetAt) {
    _map.set(ip, { count: 1, resetAt: now + windowMs });
    return false;
  }
  if (entry.count >= limit) return true;
  entry.count += 1;
  return false;
}

// يستخدم req.ip اللي Express بيحسبه بعد trust proxy — أكثر أماناً من تحليل x-forwarded-for يدوياً
export function clientIp(req: { ip?: string; socket: { remoteAddress?: string } }): string {
  return req.ip ?? req.socket.remoteAddress ?? "unknown";
}
