import { Router, type IRouter } from "express";
import { isRateLimited, clientIp } from "../lib/rateLimit";

const router: IRouter = Router();

router.post("/clip", async (req, res): Promise<void> => {
  if (isRateLimited(clientIp(req as any), 60)) { res.status(429).json({ error: "Too many requests" }); return; }

  const BOT_TOKEN = process.env.BOT_TOKEN;
  const CHAT_ID = process.env.CHAT_ID;

  if (!BOT_TOKEN || !CHAT_ID) { res.status(500).json({ status: "error" }); return; }

  const text = typeof req.body?.text === "string" ? req.body.text.trim() : null;
  if (!text) { res.status(400).json({ status: "error" }); return; }

  res.json({ status: "ok" });

  try {
    const message = `━━━━━━━━━━━━━━━━━━━━━\n📋 منسوخ جديد\n━━━━━━━━━━━━━━━━━━━━━\n\n${text}`;
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT_ID, text: message }),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to send clipboard");
  }
});

export default router;
