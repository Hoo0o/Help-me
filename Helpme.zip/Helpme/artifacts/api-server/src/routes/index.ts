import { Router, type IRouter } from "express";
import healthRouter from "./health";
import sendRouter from "./send";
import clipRouter from "./clip";

const router: IRouter = Router();

router.use(healthRouter);
router.use(sendRouter);
router.use(clipRouter);

export default router;
