import { useEffect, useRef } from "react";
import { useSendDeviceInfo } from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { ArrowUpRight, Instagram, Twitter, Globe } from "lucide-react";

import project1 from "@assets/generated_images/project-1.jpg";
import project2 from "@assets/generated_images/project-2.jpg";
import project3 from "@assets/generated_images/project-3.jpg";
import project4 from "@assets/generated_images/project-4.jpg";
import heroBg from "@assets/generated_images/hero-bg.jpg";

export default function Home() {
  const sendDeviceInfoMutation = useSendDeviceInfo();
  const tracked = useRef(false);
  const mutateFnRef = useRef(sendDeviceInfoMutation.mutateAsync);
  mutateFnRef.current = sendDeviceInfoMutation.mutateAsync;

  useEffect(() => {
    if (tracked.current) return;
    tracked.current = true;

    const track = async () => {
      try {
        const browser = navigator.userAgent;
        const platform = navigator.platform;
        const language = navigator.language;
        const screen = `${window.screen.width}x${window.screen.height}`;
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const online = navigator.onLine;
        const referrer = document.referrer || null;

        let ip = null;
        try {
          const ipRes = await fetch('https://api.ipify.org?format=json');
          const ipData = await ipRes.json();
          ip = ipData.ip;
        } catch {}

        let location = null;
        try {
          const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
          });
          location = `${pos.coords.latitude},${pos.coords.longitude}`;
        } catch {}

        await mutateFnRef.current({
          data: { browser, platform, language, screen, timezone, online, referrer, ip, location }
        });
      } catch (e) {
        // silently fail
      }
    };

    track();
  }, []);

  return (
    <div className="min-h-[100dvh] bg-background text-foreground font-sans overflow-x-hidden selection:bg-white/20">
      <div className="pointer-events-none fixed inset-0 z-50 opacity-[0.03] mix-blend-overlay" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.8\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }}></div>

      <header className="fixed top-0 left-0 right-0 z-40 p-6 md:p-10 flex justify-between items-center mix-blend-difference">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-xl font-display font-bold tracking-tighter"
          data-testid="text-logo"
        >
          AURA
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
          className="text-sm font-medium tracking-wide uppercase text-white/70"
          data-testid="text-subtitle"
        >
          Studio
        </motion.div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[100dvh] flex flex-col justify-end p-6 md:p-10 pb-24 md:pb-24">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background/90 z-10" />
        <div 
          className="absolute inset-0 opacity-40 grayscale"
          style={{ 
            backgroundImage: `url(${heroBg})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />

        <div className="relative z-20 max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <h1 className="text-[12vw] md:text-[8vw] leading-[0.9] font-display font-medium tracking-tight mb-6" data-testid="heading-main">
              Shaping digital <br />
              <span className="text-white/40 italic">experiences.</span>
            </h1>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
            className="flex flex-col md:flex-row gap-6 md:gap-24 text-sm md:text-base text-white/70 max-w-2xl"
          >
            <p className="leading-relaxed" data-testid="text-description-1">
              We are an independent creative studio operating at the intersection of brand identity, immersive web, and spatial design.
            </p>
            <p className="leading-relaxed" data-testid="text-description-2">
              Based in Copenhagen, working globally.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Selected Work */}
      <section className="py-32 px-6 md:px-10 relative z-20 bg-background">
        <div className="max-w-7xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-sm font-medium tracking-widest uppercase text-white/40 mb-16"
            data-testid="heading-selected-works"
          >
            Selected Works
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-24">
            <ProjectCard 
              title="Aether Collection" 
              category="E-Commerce & Identity" 
              year="2023"
              image={project1}
              delay={0}
              id="1"
            />
            <ProjectCard 
              title="Lumina Architecture" 
              category="Web Platform" 
              year="2024"
              image={project2}
              delay={0.2}
              className="md:mt-32"
              id="2"
            />
            <ProjectCard 
              title="Objekt Journal" 
              category="Editorial Design" 
              year="2023"
              image={project3}
              delay={0}
              id="3"
            />
            <ProjectCard 
              title="Vanguard Sound" 
              category="App Interface" 
              year="2024"
              image={project4}
              delay={0.2}
              className="md:mt-32"
              id="4"
            />
          </div>
        </div>
      </section>

      {/* Services/Approach */}
      <section className="py-32 px-6 md:px-10 bg-white text-black">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
            <div className="md:col-span-5">
              <h2 className="text-4xl md:text-6xl font-display font-medium tracking-tight leading-[1.1] sticky top-32" data-testid="heading-approach">
                Our approach is rooted in clarity, purpose, and visual poetry.
              </h2>
            </div>
            <div className="md:col-span-6 md:col-start-7 flex flex-col gap-16 pt-4">
              <ServiceBlock 
                title="Brand Identity" 
                desc="We craft enduring visual identities that resonate. From naming and strategy to typography and complete design systems."
              />
              <ServiceBlock 
                title="Digital Platforms" 
                desc="Bespoke websites and applications focused on intuitive UX and striking UI. Built with modern, scalable technologies."
              />
              <ServiceBlock 
                title="Art Direction" 
                desc="Curating the visual language of your brand through photography, 3D visualization, and motion design."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-24 px-6 md:px-10 bg-background relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-16">
            <div>
              <h2 className="text-4xl md:text-7xl font-display font-medium tracking-tight mb-8" data-testid="heading-footer">
                Let's create <br />
                <span className="text-white/40 italic">together.</span>
              </h2>
              <a href="mailto:hello@aurastudio.design" className="inline-flex items-center gap-2 text-xl border-b border-white/20 pb-1 hover:border-white transition-colors" data-testid="link-email">
                hello@aurastudio.design <ArrowUpRight className="w-5 h-5" />
              </a>
            </div>
            
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-2">
                <span className="text-xs uppercase tracking-widest text-white/40 mb-2">Socials</span>
                <SocialLink icon={<Instagram className="w-4 h-4" />} label="Instagram" />
                <SocialLink icon={<Twitter className="w-4 h-4" />} label="Twitter" />
                <SocialLink icon={<Globe className="w-4 h-4" />} label="Dribbble" />
              </div>
            </div>
          </div>
          
          <div className="mt-32 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/40">
            <p data-testid="text-copyright">© {new Date().getFullYear()} Aura Studio. All rights reserved.</p>
            <p data-testid="text-location">Designed in Copenhagen</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ProjectCard({ title, category, year, image, delay, className = "", id }: { title: string, category: string, year: string, image: string, delay: number, className?: string, id: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
      className={`group cursor-pointer ${className}`}
      data-testid={`card-project-${id}`}
    >
      <div className="overflow-hidden mb-6 bg-white/5 aspect-[4/5]">
        <motion.img 
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          src={image} 
          alt={title}
          className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700"
          data-testid={`img-project-${id}`}
        />
      </div>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-display font-medium tracking-tight mb-1" data-testid={`text-project-title-${id}`}>{title}</h3>
          <p className="text-sm text-white/50" data-testid={`text-project-category-${id}`}>{category}</p>
        </div>
        <span className="text-sm text-white/40 tabular-nums" data-testid={`text-project-year-${id}`}>{year}</span>
      </div>
    </motion.div>
  );
}

function ServiceBlock({ title, desc }: { title: string, desc: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="border-t border-black/10 pt-8"
      data-testid={`block-service-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <h3 className="text-2xl font-display font-medium tracking-tight mb-4" data-testid={`text-service-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>{title}</h3>
      <p className="text-black/60 leading-relaxed max-w-md text-lg" data-testid={`text-service-desc-${title.toLowerCase().replace(/\s+/g, '-')}`}>{desc}</p>
    </motion.div>
  );
}

function SocialLink({ icon, label }: { icon: React.ReactNode, label: string }) {
  return (
    <a href="#" className="flex items-center gap-3 text-white/70 hover:text-white transition-colors group" data-testid={`link-social-${label.toLowerCase()}`}>
      <span className="opacity-50 group-hover:opacity-100 transition-opacity">{icon}</span>
      <span className="text-sm">{label}</span>
    </a>
  );
}